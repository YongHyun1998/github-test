//UCC size placeholder 추가
if ($('.uccUrlSize').val() != undefined) {
    $('#ucc_width').attr('placeholder', '넓이');
    $('#ucc_width').attr('value', '');
    $('#ucc_height').attr('placeholder', '높이');
    $('#ucc_height').attr('value', '');
}